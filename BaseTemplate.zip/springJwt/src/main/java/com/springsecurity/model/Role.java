package com.springsecurity.model;

public enum Role {
    USER,
    ADMIN
}
